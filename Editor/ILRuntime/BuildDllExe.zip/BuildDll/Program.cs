﻿using System.Text;
using BuildDll;
using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.Emit;
using Newtonsoft.Json;

var paramsPath = args[0];
if (!File.Exists(paramsPath))
{
    throw new FileNotFoundException($"{paramsPath} is not found");
}

BuildParams? buildParams = JsonConvert.DeserializeObject<BuildParams>(File.ReadAllText(paramsPath));
if (buildParams == null)
{
    throw new Exception("解析json失败");
}

BuildByRoslyn(buildParams.Dlls, buildParams.CodeFiles, buildParams.Output, buildParams.DefineList, buildParams.UsePdb);

static bool BuildByRoslyn(List<string> dlls, List<string> codefiles, string output, List<string> defineList, bool usePdb)
{
    //添加语法树
    List<Microsoft.CodeAnalysis.SyntaxTree> codes = new List<Microsoft.CodeAnalysis.SyntaxTree>();
    var opa = new CSharpParseOptions(LanguageVersion.Latest, preprocessorSymbols: defineList);
    foreach (var cs in codefiles)
    {
        //判断文件是否存在
        if (!File.Exists(cs)) continue;
        //
        var content = File.ReadAllText(cs);
        var syntaxTree = CSharpSyntaxTree.ParseText(content, opa, cs, Encoding.UTF8);
        codes.Add(syntaxTree);
    }

    //添加dll
    List<MetadataReference> assemblies = new List<MetadataReference>();
    foreach (var dll in dlls)
    {
        var metaref = MetadataReference.CreateFromFile(dll);
        if (metaref != null)
        {
            assemblies.Add(metaref);
        }
    }

    //创建目录
    var dir = Path.GetDirectoryName(output);
    Directory.CreateDirectory(dir);
    //编译参数
    CSharpCompilationOptions option = new CSharpCompilationOptions(OutputKind.DynamicallyLinkedLibrary,
        optimizationLevel: OptimizationLevel.Release, warningLevel: 4,
        allowUnsafe: true);

    //创建编译器代理
    var assemblyname = Path.GetFileNameWithoutExtension(output);
    var compilation = CSharpCompilation.Create(assemblyname, codes, assemblies, option);
    EmitResult result = null;
    var pdbPath = Path.ChangeExtension(output, "pdb");
    var emitOptions = new EmitOptions(debugInformationFormat: DebugInformationFormat.PortablePdb,
        pdbFilePath: pdbPath);
    using (var dllStream = new MemoryStream())
    using (var pdbStream = new MemoryStream())
    {
        result = compilation.Emit(dllStream, pdbStream, options: emitOptions);
        File.WriteAllBytes(output + ".bytes", dllStream.GetBuffer());
        pdbPath += ".bytes";
        if (File.Exists(pdbPath))
            File.Delete(pdbPath);
        if (usePdb)
        {
            File.WriteAllBytes(pdbPath, pdbStream.GetBuffer());
        }
    }

    // 编译失败，提示
    if (!result.Success)
    {
        IEnumerable<Diagnostic> failures = result.Diagnostics.Where(diagnostic =>
            diagnostic.IsWarningAsError ||
            diagnostic.Severity ==
            DiagnosticSeverity.Error);
        StringBuilder sb = new StringBuilder();
        foreach (var diagnostic in failures)
        {
            sb.AppendLine(diagnostic.ToString());
        }
        throw new Exception(sb.ToString());
    }
    else
    {
        Console.WriteLine("编译DLL成功");
    }
    return result.Success;
}