﻿namespace BuildDll;

public class BuildParams
{
    public List<string> Dlls;
    public List<string> CodeFiles;
    public string Output;
    public List<string> DefineList;
    public bool UsePdb;
}